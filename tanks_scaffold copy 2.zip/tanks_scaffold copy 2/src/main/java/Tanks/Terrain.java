package Tanks;
public class Terrain {
    private int x;
    private int y;

    public Terrain(int x, int y) {
        this.x = x;
        this.y = y;
    }

    // Getters and possibly rendering methods here
}
