package Tanks;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Level {
    private List<Terrain> terrains;
    private Map<Character, Player> players;
    private List<Tree> trees;

    public Level() {
        terrains = new ArrayList<>();
        players = new HashMap<>();
        trees = new ArrayList<>();
    }

    public void loadLevel(String layoutPath, String background, String foregroundColour, String treesImg) {
        System.out.println("Loading level from: " + layoutPath);
        System.out.println("Background: " + background);
        System.out.println("Foreground Colour: " + foregroundColour);
        if (treesImg != null) {
            System.out.println("Trees image: " + treesImg);
        }
    }

    public void addTerrain(int x, int y) {
        Terrain terrain = new Terrain(x, y);
        terrains.add(terrain);
    }

    public void addTree(int x, int y) {
        Tree tree = new Tree(x, y);
        trees.add(tree);
    }

    public void addPlayer(char identifier, int x, int y) {
        if (!players.containsKey(identifier)) {
            Player player = new Player(x, y);
            players.put(identifier, player);
        } else {
            // Update the player's position if they already exist
            Player player = players.get(identifier);
            player.setPosition(x, y);  // Make sure this method is defined in Player class
        }
    }
    public Player getCurrentPlayer() {
        // Implement logic to determine the current player
        // For simplicity, you might return the first player or based on some condition
        return players.values().iterator().next(); // Just return the first player for now
    }
    

    // Additional methods to manage terrain, players, and trees
}
