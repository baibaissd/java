package Tanks;
import Tanks.Player;
import Tanks.Terrain;
import Tanks.Tree;
import Tanks.Level;

import processing.core.PApplet;
import processing.core.PImage;
import processing.data.JSONArray;
import processing.data.JSONObject;
import processing.event.KeyEvent;
import processing.event.MouseEvent;

import java.awt.*;
import java.awt.geom.AffineTransform;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class App extends PApplet {

    public static final int CELLSIZE = 32;
    public static final int CELLHEIGHT = 32;
    public static final int CELLAVG = 32;
    public static final int TOPBAR = 0;
    public static int WIDTH = 864;
    public static int HEIGHT = 640;
    public static final int BOARD_WIDTH = WIDTH / CELLSIZE;
    public static final int BOARD_HEIGHT = 20;
    public static final int INITIAL_PARACHUTES = 1;
    public static final int FPS = 30;

    public String configPath;
    public static Random random = new Random();

    private List<Level> gameLevels;
    private int currentLevelIndex;
    private Level currentLevel;

    public App() {
        this.configPath = "config.json";
    }

    @Override
    public void settings() {
        size(WIDTH, HEIGHT);
    }

    /**
     * Load all resources such as images. Initialise the elements such as the player, enemies and map elements.
     */
    @Override
    public void setup() {
        frameRate(FPS);
        JSONObject config = loadJSONObject(configPath);
        JSONArray levels = config.getJSONArray("levels");
        
        gameLevels = new ArrayList<>();
        for (int i = 0; i < levels.size(); i++) {
            JSONObject levelConfig = levels.getJSONObject(i);
            String layoutPath = levelConfig.getString("layout");
            String background = levelConfig.getString("background");
            String foregroundColour = levelConfig.getString("foreground-colour");
            String trees = null;
            try {
                trees = levelConfig.getString("trees");
            } catch (Exception e) {
                trees = null;  // 如果没有'trees'键，则设置为null
            }
            
        
            Level level = new Level();
            level.loadLevel(layoutPath, background, foregroundColour, trees);
            gameLevels.add(level);
        }
        
        currentLevelIndex = 0;
        currentLevel = gameLevels.get(currentLevelIndex);
    }

    public void switchLevel(int levelIndex) {
        if (levelIndex >= 0 && levelIndex < gameLevels.size()) {
            currentLevelIndex = levelIndex;
            currentLevel = gameLevels.get(currentLevelIndex);
        }
    }
    // Helper method to initialize a level
    private Level initializeLevel(String layoutPath) {
        String[] lines = loadStrings(layoutPath);
        Level level = new Level();
    
        // Parse each line in the layout file
        for (int i = 0; i < lines.length; i++) {
            for (int j = 0; j < lines[i].length(); j++) {
                char c = lines[i].charAt(j);
                switch(c) {
                    case 'X':
                        level.addTerrain(j, i);
                        break;
                    case 'T':
                        level.addTree(j, i);
                        break;
                    case ' ':
                        // Ignore spaces
                        break;
                    default:
                        if (Character.isLetter(c)) { // Assuming all letters are players
                            level.addPlayer(c, j, i);
                        }
                        break;
                }
            }
        }
        return level;
    }
    
    @Override
    public void keyPressed(KeyEvent event) {
        switch (event.getKeyCode()) {
            case LEFT:
                // Assuming getCurrentPlayer() is a method in Level class that returns the current active player
                currentLevel.getCurrentPlayer().moveLeft();
                break;
            case RIGHT:
                currentLevel.getCurrentPlayer().moveRight();
                break;
            // Add other cases for different controls
        }
    }


	@Override
    public void keyReleased(){
        
    }

    @Override
    public void mousePressed(MouseEvent e) {
        //TODO - powerups, like repair and extra fuel and teleport? - or maybe leave this as an extension


    }

    @Override
    public void mouseReleased(MouseEvent e) {

    }


	@Override
    public void draw() {
        

        //----------------------------------
        //display HUD:
        //----------------------------------
        //TODO

        //----------------------------------
        //display scoreboard:
        //----------------------------------
        //TODO
        
		//----------------------------------
        //----------------------------------

        //TODO: Check user action
    }


    public static void main(String[] args) {
        PApplet.main("Tanks.App");
    }

}
