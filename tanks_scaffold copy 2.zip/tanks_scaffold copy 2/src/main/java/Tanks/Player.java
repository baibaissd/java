package Tanks;

public class Player {
    private int x, y; // Player's position coordinates

    public Player(int x, int y) {
        this.x = x;
        this.y = y;
    }

    // Method to update player's position
    public void setPosition(int x, int y) {
        this.x = x;
        this.y = y;
    }

    // Method to move player to the left
    public void moveLeft() {
        this.x -= 5; // Assume moving 5 units left
    }

    // Method to move player to the right
    public void moveRight() {
        this.x += 5; // Assume moving 5 units right
    }
}
