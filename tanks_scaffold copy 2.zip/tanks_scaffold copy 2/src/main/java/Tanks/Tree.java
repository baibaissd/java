package Tanks;
public class Tree {
    private int x;
    private int y;

    public Tree(int x, int y) {
        this.x = x;
        this.y = y;
    }

    // Possibly include methods to render the tree on the game screen
}
